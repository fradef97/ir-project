import subprocess
from itertools import product
import yaml


def update_config_file(file_path, new_combination):
    with open(file_path, 'r', encoding="utf8") as file:
        config = yaml.safe_load(file)

    # Update the config with new combination values
    for key, value in new_combination.items():
        if key in config:
            config[key] = value

    with open(file_path, "w", encoding="utf8") as file:
        yaml.safe_dump(config, file)


def run_experiment(venv_path: str=None):
    if venv_path is None:
        venv_path = "python"

    command = [venv_path, "run_hopwise.py", "--config", "config.yaml"]
    result = subprocess.run(command, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(result.stderr)


if __name__ == "__main__":

    VENV_PATH = "D:/venvir/Scripts/python.exe"

    models = [
        "TransE",
        "TransR",
        "TransH",
        "TransD",
        "TorusE",
        "CFKG",
        # "CKE",
        "KGAT"
    ]

    param_space = {
        "model": [
            # "TransE",
            "TransR",
            "TransH",
            "TransD",
            "TorusE",
            "CFKG",
            # "CKE",
            "KGAT"
        ],
        "learning_rate": [2e-3, 2e-4, 2e-5],
        "embedding_size": [64, 128, 256, 512],

        "epochs": [30],
        "train_batch_size": [64],
        "path_hop_length": [5],
    }

    # create dict of all possible combinations
    param_names = list(param_space.keys())
    all_comb = [dict(zip(param_names, values)) for values in product(*param_space.values())]

    for comb in all_comb:
        print(comb)
        update_config_file("./config.yaml", comb)

        # run experiment with updated config
        run_experiment(VENV_PATH)
