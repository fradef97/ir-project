from hopwise.config.configurator import Config
